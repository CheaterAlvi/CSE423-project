from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *
import random

rain_drops = []
rain_direction = 0
background_color = [0.0, 0.0, 0.0]
house_bounds = [150, 350, 50, 250]

def draw_house():
    glColor3f(0.4, 0.6, 0.2)
    glBegin(GL_LINES)
    glVertex2f(150, 50)
    glVertex2f(150, 250)
    glVertex2f(150, 250)
    glVertex2f(350, 250)
    glVertex2f(350, 250)
    glVertex2f(350, 50)
    glVertex2f(350, 50)
    glVertex2f(150, 50)
    glEnd()

    glColor3f(0.8, 0.3, 0.3)
    glBegin(GL_TRIANGLES)
    glVertex2f(150, 250)
    glVertex2f(350, 250)
    glVertex2f(250, 350)
    glEnd()

    glColor3f(0.5, 0.3, 0.1)
    glBegin(GL_LINES)
    glVertex2f(170, 50)
    glVertex2f(170, 150)
    glVertex2f(200, 50)
    glVertex2f(200, 150)
    glVertex2f(170, 150)
    glVertex2f(200, 150)
    glEnd()

    glColor3f(0.2, 0.4, 0.9)
    glBegin(GL_LINES)
    glVertex2f(270, 200)
    glVertex2f(270, 150)
    glVertex2f(270, 150)
    glVertex2f(320, 150)
    glVertex2f(320, 150)
    glVertex2f(320, 200)
    glVertex2f(320, 200)
    glVertex2f(270, 200)
    glVertex2f(295, 200)
    glVertex2f(295, 150)
    glVertex2f(270, 175)
    glVertex2f(320, 175)
    glEnd()

def create_raindrop():
    x = random.randint(0, 500)
    y = random.randint(400, 500)
    rain_drops.append([x, y])

def draw_rain():
    global rain_drops, rain_direction
    glColor3f(0.5, 0.5, 1.0)
    glBegin(GL_LINES)
    for drop in rain_drops:
        x, y = drop[0], drop[1]
        if house_bounds[0] <= x <= house_bounds[1]:
            roof_slope = (350 - 250) / (250 - 150)
            roof_y = 350 - abs(x - 250) * roof_slope
            if y <= roof_y:
                drop[1] = random.randint(400, 500)
                drop[0] = random.randint(0, 500)
                continue

        glVertex2f(x, y)
        glVertex2f(x + rain_direction * 5, y - 10)

        drop[1] -= 5
        drop[0] += rain_direction * 2
        if drop[1] < 0:
            drop[1] = random.randint(400, 500)
            drop[0] = random.randint(0, 500)
    glEnd()

def keyboard_listener(key, x, y):
    global background_color
    if key == b'd':
        background_color = [1.0, 1.0, 1.0]
    elif key == b'n':
        background_color = [0.0, 0.0, 0.0]
    glutPostRedisplay()

def special_key_listener(key, x, y):
    global rain_direction
    if key == GLUT_KEY_LEFT:
        rain_direction = max(-1, rain_direction - 1)
    elif key == GLUT_KEY_RIGHT:
        rain_direction = min(1, rain_direction + 1)
    glutPostRedisplay()

def display():
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glClearColor(background_color[0], background_color[1], background_color[2], 1.0)
    glLoadIdentity()
    gluOrtho2D(0, 500, 0, 500)
    draw_house()
    draw_rain()
    glutSwapBuffers()

def animate():
    if len(rain_drops) < 100:
        create_raindrop()
    glutPostRedisplay()

glutInit()
glutInitDisplayMode(GLUT_RGBA)
glutInitDisplayMode(GLUT_DEPTH)
glutInitDisplayMode(GLUT_DOUBLE)
glutInitWindowSize(500, 500)
glutCreateWindow(b"House in Rainfall")
glutDisplayFunc(display)
glutIdleFunc(animate)
glutKeyboardFunc(keyboard_listener)
glutSpecialFunc(special_key_listener)
glLineWidth(2)
glutMainLoop()
