from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *
import random
import time

# Globals
points = []
box_left_position = 0
box_width = 900
box_bottom_position = 0
box_height = 700
point_size = 14
point_speed = 0.05
clicked_left_mouse = False
blink_status = []
last_blink_time = time.time()
spacebar = False

def draw_points():
    global blink_status, last_blink_time, spacebar
    glEnable(GL_POINT_SMOOTH)
    glPointSize(point_size)
    glBegin(GL_POINTS)
    current_time = time.time()

    #blining
    if clicked_left_mouse and not spacebar:
        if current_time - last_blink_time >= 0.5:
            blink_status = [not status for status in blink_status]
            last_blink_time = current_time

    # Loop through all points
    for i, (x, y, color, dx, dy) in enumerate(points):
        if not spacebar:
            x += dx * point_speed
            y += dy * point_speed

            if x < box_left_position + point_size or x > box_width - point_size:
                dx = -dx
            if y < box_bottom_position + point_size or y > box_height - point_size:
                dy = -dy
            points[i] = (x, y, color, dx, dy)

        if clicked_left_mouse and not blink_status[i]:
            glColor3f(0, 0, 0)
        else:
            glColor3f(*color)
        glVertex2f(x, y)
    glEnd()

def create_random_point(x, y):

    if box_left_position + point_size < x < box_width - point_size:
        if box_bottom_position + point_size < y < box_height - point_size:

            r = random.random()
            g = random.random()
            b = random.random()
            dx = random.choice([-1, 1])
            dy = random.choice([-1, 1])
            points.append((x, y, (r, g, b), dx, dy))
            blink_status.append(True)

def mouse_listener(button, state, x, y):
    global clicked_left_mouse, spacebar


    if button == GLUT_RIGHT_BUTTON and state == GLUT_DOWN and not spacebar:
        create_random_point(x, 700 - y)


    if button == GLUT_LEFT_BUTTON and state == GLUT_DOWN and not spacebar:
        clicked_left_mouse = not clicked_left_mouse
        if clicked_left_mouse:
            print("Blinking: Enabled")
        else:
            print("Blinking: Disabled")

def special_keys_listener(key, x, y):

    global point_speed, spacebar


    if key == GLUT_KEY_UP and not spacebar:
        point_speed += 0.01
        print("Speed Increased")
    elif key == GLUT_KEY_DOWN and not spacebar:
        point_speed = max(0.01, point_speed - 0.01)
        print("Speed Decreased")

def keyboard_listener(key, x, y):
    global spacebar

    if key == b" ":
        spacebar = not spacebar  # Toggle the spacebar status
        if spacebar:
            print("Animation Frozen")
        else:
            print("Animation Resumed")

def draw_box():
    glColor3f(1, 1, 1)
    glLineWidth(2)
    glBegin(GL_LINES)

    glVertex2f(box_left_position, box_bottom_position)
    glVertex2f(box_width, box_bottom_position)
    glVertex2f(box_width, box_bottom_position)
    glVertex2f(box_width, box_height)
    glVertex2f(box_width, box_height)
    glVertex2f(box_left_position, box_height)
    glVertex2f(box_left_position, box_height)
    glVertex2f(box_left_position, box_bottom_position)
    glEnd()

def iterate():
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    glOrtho(0, 900, 0, 700, -1, 1)
    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()

def display():
    glClear(GL_COLOR_BUFFER_BIT)
    glLoadIdentity()
    iterate()
    draw_box()
    draw_points()
    glutSwapBuffers()


glutInit()
glutInitDisplayMode(GLUT_RGBA)
glutInitDisplayMode(GLUT_DOUBLE)
glutInitWindowSize(box_width, box_height)
glutCreateWindow(b"Amazing Box")


glutDisplayFunc(display)
glutMouseFunc(mouse_listener)
glutSpecialFunc(special_keys_listener)
glutKeyboardFunc(keyboard_listener)
glutIdleFunc(display)
glutMainLoop()

